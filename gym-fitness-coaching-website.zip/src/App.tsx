import { AnimatePresence, motion } from "framer-motion";
import { useState } from "react";

const coachingTracks = [
  {
    id: "fat-loss",
    name: "Fat Loss",
    outcome: "Drop body fat while protecting muscle and strength.",
    bullets: [
      "Personalized calorie and protein targets",
      "3 to 5 gym sessions with progression built in",
      "Weekly check-ins and adherence coaching",
    ],
  },
  {
    id: "muscle-gain",
    name: "Muscle Gain",
    outcome: "Build visible size with clean technique and consistent overload.",
    bullets: [
      "Hypertrophy split built around your schedule",
      "Exercise library with form cues from your coach",
      "Monthly performance tests to track growth",
    ],
  },
  {
    id: "strength",
    name: "Strength",
    outcome: "Add kilos to your barbell lifts with smart periodization.",
    bullets: [
      "Squat, bench, deadlift programming",
      "Load planning with RPE and recovery controls",
      "Mobility prep to keep heavy sessions pain free",
    ],
  },
];

const reveal = {
  hidden: { opacity: 0, y: 26 },
  visible: { opacity: 1, y: 0 },
};

const rates = [
  {
    plan: "Starter",
    price: "Rs 2,999",
    cycle: "per month",
    detail: "Training plan + bi-weekly check-ins.",
  },
  {
    plan: "Most Popular",
    price: "Rs 4,999",
    cycle: "per month",
    detail: "Full coaching with weekly reviews and nutrition updates.",
  },
  {
    plan: "Elite",
    price: "Rs 7,999",
    cycle: "per month",
    detail: "Priority support with deep form and performance coaching.",
  },
];

export default function App() {
  const [activeTrack, setActiveTrack] = useState(coachingTracks[0]);

  return (
    <div className="bg-black text-zinc-100">
      <header className="fixed inset-x-0 top-0 z-50 border-b border-white/10 bg-black/80 backdrop-blur-lg">
        <nav className="mx-auto flex h-16 w-full max-w-6xl items-center justify-between px-5 sm:px-8">
          <a href="#home" className="text-xs font-semibold tracking-[0.22em] text-white sm:text-sm">
            IRON BAR FITNESS COACHING
          </a>
          <div className="flex items-center gap-6">
            <a href="#tracks" className="hidden text-xs tracking-[0.14em] text-zinc-300 transition hover:text-white sm:block">
              PROGRAMS
            </a>
            <a href="#rates" className="hidden text-xs tracking-[0.14em] text-zinc-300 transition hover:text-white sm:block">
              RATES
            </a>
            <a href="#consultation" className="text-xs font-semibold tracking-[0.14em] text-orange-400 transition hover:text-orange-300">
              BOOK CONSULT
            </a>
          </div>
        </nav>
      </header>

      <main>
        <section id="home" className="relative isolate flex min-h-screen items-end overflow-hidden">
          <motion.img
            src="/images/gym-hero.jpg"
            alt="Coach assisting a client during a barbell session"
            initial={{ scale: 1.1 }}
            animate={{ scale: 1 }}
            transition={{ duration: 1.8, ease: [0.22, 1, 0.36, 1] }}
            className="absolute inset-0 -z-20 h-full w-full object-cover"
          />
          <div className="absolute inset-0 -z-10 bg-gradient-to-t from-black via-black/65 to-black/35" />

          <div className="mx-auto w-full max-w-6xl px-5 pt-28 pb-16 sm:px-8 sm:pb-20">
            <motion.div initial="hidden" animate="visible" transition={{ staggerChildren: 0.12 }} className="max-w-4xl">
              <motion.p
                variants={reveal}
                transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
                className="text-sm font-semibold tracking-[0.34em] text-orange-300"
              >
                IRON BAR FITNESS COACHING
              </motion.p>
              <motion.h1
                variants={reveal}
                transition={{ duration: 0.64, ease: [0.22, 1, 0.36, 1] }}
                className="mt-5 text-4xl leading-tight font-semibold text-white sm:text-6xl"
              >
                Train with structure. Eat with intent. Build a body that performs.
              </motion.h1>
              <motion.p
                variants={reveal}
                transition={{ duration: 0.64, ease: [0.22, 1, 0.36, 1] }}
                className="mt-6 max-w-2xl text-base text-zinc-200 sm:text-lg"
              >
                Inspired by modern fitness platforms, this coaching system combines real gym programming, nutrition accountability, and weekly expert feedback.
              </motion.p>
              <motion.div
                variants={reveal}
                transition={{ duration: 0.64, ease: [0.22, 1, 0.36, 1] }}
                className="mt-9 flex flex-wrap gap-4"
              >
                <a href="#consultation" className="bg-orange-500 px-7 py-3 text-sm font-semibold tracking-[0.11em] text-black transition hover:bg-orange-400">
                  START COACHING
                </a>
                <a
                  href="#tracks"
                  className="border border-white/35 px-7 py-3 text-sm font-semibold tracking-[0.11em] text-white transition hover:border-orange-400 hover:text-orange-300"
                >
                  EXPLORE TRACKS
                </a>
              </motion.div>
            </motion.div>
          </div>
        </section>

        <section className="border-y border-white/10 bg-[#080808] py-16">
          <motion.div
            variants={reveal}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, amount: 0.45 }}
            transition={{ duration: 0.55, ease: [0.22, 1, 0.36, 1] }}
            className="mx-auto grid max-w-6xl gap-8 px-5 sm:grid-cols-3 sm:px-8"
          >
            <div>
              <p className="text-sm tracking-[0.2em] text-orange-300 uppercase">Train</p>
              <p className="mt-2 text-zinc-300">Progressive sessions built for your current level and goals.</p>
            </div>
            <div>
              <p className="text-sm tracking-[0.2em] text-orange-300 uppercase">Fuel</p>
              <p className="mt-2 text-zinc-300">Nutrition targets adjusted weekly based on your real progress.</p>
            </div>
            <div>
              <p className="text-sm tracking-[0.2em] text-orange-300 uppercase">Recover</p>
              <p className="mt-2 text-zinc-300">Sleep, stress, and mobility guidance to keep momentum high.</p>
            </div>
          </motion.div>
        </section>

        <section id="tracks" className="mx-auto max-w-6xl px-5 py-20 sm:px-8">
          <motion.div
            variants={reveal}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, amount: 0.35 }}
            transition={{ duration: 0.55, ease: [0.22, 1, 0.36, 1] }}
            className="max-w-3xl"
          >
            <h2 className="text-3xl font-semibold text-white sm:text-4xl">Pick Your Coaching Track</h2>
            <p className="mt-3 text-zinc-300">Choose the path that matches your main outcome. Your plan is then tailored to your schedule, injury history, and training age.</p>
          </motion.div>

          <div className="mt-10 grid gap-8 lg:grid-cols-[1.2fr_1.8fr]">
            <motion.div
              variants={reveal}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true, amount: 0.4 }}
              transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
              className="space-y-3"
            >
              {coachingTracks.map((track) => (
                <button
                  key={track.id}
                  type="button"
                  onClick={() => setActiveTrack(track)}
                  className={`w-full border px-5 py-4 text-left text-sm font-semibold tracking-[0.1em] transition ${
                    activeTrack.id === track.id
                      ? "border-orange-400 bg-orange-500/10 text-orange-100"
                      : "border-white/20 text-zinc-300 hover:border-white/45 hover:text-white"
                  }`}
                >
                  {track.name}
                </button>
              ))}
            </motion.div>

            <motion.div
              variants={reveal}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true, amount: 0.4 }}
              transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1], delay: 0.08 }}
              className="border border-white/15 bg-zinc-950 p-7 sm:p-9"
            >
              <AnimatePresence mode="wait">
                <motion.div
                  key={activeTrack.id}
                  initial={{ opacity: 0, y: 12 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  transition={{ duration: 0.32, ease: "easeOut" }}
                >
                  <p className="text-xs tracking-[0.22em] text-orange-300 uppercase">{activeTrack.name} Track</p>
                  <p className="mt-4 text-2xl font-semibold text-white sm:text-3xl">{activeTrack.outcome}</p>
                  <ul className="mt-6 space-y-3 text-zinc-300">
                    {activeTrack.bullets.map((bullet) => (
                      <li key={bullet} className="border-l border-orange-400/70 pl-4">
                        {bullet}
                      </li>
                    ))}
                  </ul>
                </motion.div>
              </AnimatePresence>
            </motion.div>
          </div>
        </section>

        <section id="rates" className="border-t border-white/10 bg-[#080808]">
          <div className="mx-auto max-w-6xl px-5 py-20 sm:px-8">
            <motion.div
              variants={reveal}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true, amount: 0.35 }}
              transition={{ duration: 0.55, ease: [0.22, 1, 0.36, 1] }}
            >
              <h2 className="text-3xl font-semibold text-white sm:text-4xl">Coaching Rates</h2>
              <p className="mt-3 max-w-2xl text-zinc-300">Choose your support level. Every plan includes customized training, nutrition direction, and weekly accountability.</p>
            </motion.div>

            <motion.div
              variants={reveal}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true, amount: 0.35 }}
              transition={{ duration: 0.55, ease: [0.22, 1, 0.36, 1], delay: 0.08 }}
              className="mt-10 overflow-hidden border border-white/15"
            >
              <div className="grid gap-0 divide-y divide-white/15 lg:grid-cols-3 lg:divide-x lg:divide-y-0">
                {rates.map((rate) => (
                  <div key={rate.plan} className={`p-6 ${rate.plan === "Most Popular" ? "bg-orange-500/10" : ""}`}>
                    <p className="text-xs tracking-[0.2em] text-orange-300 uppercase">{rate.plan}</p>
                    <p className="mt-3 text-4xl font-semibold text-white">{rate.price}</p>
                    <p className="mt-1 text-sm text-zinc-400">{rate.cycle}</p>
                    <p className="mt-4 text-zinc-300">{rate.detail}</p>
                  </div>
                ))}
              </div>
            </motion.div>
          </div>
        </section>

        <section id="consultation" className="border-t border-white/10 bg-black">
          <div className="mx-auto grid max-w-6xl gap-10 px-5 py-20 sm:px-8 lg:grid-cols-2">
            <motion.div
              variants={reveal}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true, amount: 0.4 }}
              transition={{ duration: 0.55, ease: [0.22, 1, 0.36, 1] }}
            >
              <h2 className="text-3xl font-semibold text-white sm:text-4xl">Book Your Free Consultation</h2>
              <p className="mt-4 max-w-md text-zinc-300">
                Share your goal, training background, and weekly availability. You will get a clear roadmap before you commit.
              </p>
            </motion.div>

            <motion.form
              variants={reveal}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true, amount: 0.4 }}
              transition={{ duration: 0.55, ease: [0.22, 1, 0.36, 1], delay: 0.08 }}
              className="space-y-4 border border-white/15 bg-[#080808] p-6"
              action="#"
              method="post"
            >
              <label className="block text-sm text-zinc-200" htmlFor="name">
                Full Name
              </label>
              <input
                id="name"
                name="name"
                type="text"
                required
                className="w-full border border-white/20 bg-black px-4 py-3 text-white outline-none transition focus:border-orange-400"
              />

              <label className="block text-sm text-zinc-200" htmlFor="email">
                Email
              </label>
              <input
                id="email"
                name="email"
                type="email"
                required
                className="w-full border border-white/20 bg-black px-4 py-3 text-white outline-none transition focus:border-orange-400"
              />

              <label className="block text-sm text-zinc-200" htmlFor="goal">
                Primary Goal
              </label>
              <textarea
                id="goal"
                name="goal"
                rows={4}
                required
                className="w-full border border-white/20 bg-black px-4 py-3 text-white outline-none transition focus:border-orange-400"
              />

              <button
                type="submit"
                className="w-full bg-orange-500 px-4 py-3 text-sm font-semibold tracking-[0.12em] text-black transition hover:bg-orange-400"
              >
                REQUEST CONSULTATION
              </button>
            </motion.form>
          </div>
        </section>
      </main>

      <footer className="border-t border-white/10 bg-black">
        <div className="mx-auto flex max-w-6xl flex-col gap-4 px-5 py-8 sm:flex-row sm:items-center sm:justify-between sm:px-8">
          <p className="text-xs tracking-[0.16em] text-zinc-400">IRON BAR FITNESS COACHING</p>
        </div>
      </footer>
    </div>
  );
}